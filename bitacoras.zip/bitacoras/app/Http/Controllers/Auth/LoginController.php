<?php

namespace App\Http\Controllers\Auth;
use App\Models\Usuario;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        // Validación
        $request->validate([
            'correo' => 'required|email',
            'password' => 'required|min:4',
        ]);

        // Intentar autenticación
        if (Auth::attempt([
            'correo' => $request->correo,
            'password' => $request->password,
        ])) {
            $request->session()->regenerate();
            return redirect()->intended('/denso');

        // Si falla
        return back()->withErrors([
            'correo' => 'Credenciales incorrectas',
        ]);
        }
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/login');
    }
}

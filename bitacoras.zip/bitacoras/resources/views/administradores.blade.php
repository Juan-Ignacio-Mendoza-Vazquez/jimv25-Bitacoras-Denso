@extends('layouts.app')

@section('content')
    <h1 class="display-1">Administradores</h1>
    <p>Sitio en construccion</p>
@endsection

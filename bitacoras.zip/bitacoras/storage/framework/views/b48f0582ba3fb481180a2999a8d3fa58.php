

<?php $__env->startSection('content'); ?>
    <h1 class="display-1">Administradores</h1>
    <p>Sitio en construccion</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexs\OneDrive\Documentos\ASB\Proyectos\DENSO\bitacoras\resources\views/welcome.blade.php ENDPATH**/ ?>
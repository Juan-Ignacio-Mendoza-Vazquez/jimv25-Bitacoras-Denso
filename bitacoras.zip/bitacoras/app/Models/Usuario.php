<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Usuario extends Authenticatable
{
    // TABLA CON ESQUEMA
    protected $table = 'denso.usuarios';

    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'nombre_completo',
        'correo',
        'password_hash'
    ];

    // Laravel usará "correo" como username
    public function username()
    {
        return 'correo';
    }

    // Laravel usará "password_hash" como contraseña
    public function getAuthPassword()
    {
        return $this->password_hash;
    }
}

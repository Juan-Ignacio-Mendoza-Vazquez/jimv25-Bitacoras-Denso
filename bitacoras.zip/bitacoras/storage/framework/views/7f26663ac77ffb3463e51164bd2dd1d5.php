

<?php $__env->startSection('content'); ?>
    <h1 class="display-1">Detalles</h1>
    <br>

    <div class="container text-start">

        <ul class="list-group">
            <li class="list-group-item"><strong>Nombre:</strong> <?php echo e($visita->name); ?></li>
            <li class="list-group-item"><strong>Compañía:</strong> <?php echo e($visita->company); ?></li>
            <li class="list-group-item"><strong>Motivo:</strong> <?php echo e($visita->reason); ?></li>
            <li class="list-group-item"><strong>Hora:</strong> <?php echo e($visita->hour); ?></li>
            <li class="list-group-item">
                <strong>Foto:</strong><br>
                <img src="<?php echo e(asset('storage/' . $visita->photo)); ?>" width="200">
            </li>
        </ul>

        <a href="<?php echo e(route('visitas.index')); ?>" class="btn btn-secondary mt-3">Volver</a>
 
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexs\OneDrive\Documentos\ASB\Proyectos\DENSO\bitacoras\resources\views/visitas/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <h1 class="display-1">Visitas</h1>
    <br>

    <div class="container text-end">
        <table class="table table-striped table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>Nombre</th>
                    <th>Compañía</th>
                    <th>Hora</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $visitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($visita->name); ?></td>
                        <td><?php echo e($visita->company); ?></td>
                        <td><?php echo e($visita->hour); ?></td>
                        <td>
                            <a href="<?php echo e(route('visitas.show', $visita->id)); ?>" class="bi bi-eye text-info me-3"></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No hay visitas registradas.</td>
                    </tr>
                <?php endif; ?>
            </tbody>

        </table>
        
        <div class="d-flex justify-content-center mt-3">
            <?php echo e($visitas->links('pagination::bootstrap-5')); ?>

        </div>
        <a href="/registro-visita" class="btn btn-outline-success">Registar</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexs\OneDrive\Documentos\ASB\Proyectos\DENSO\bitacoras\resources\views/visitas/index.blade.php ENDPATH**/ ?>
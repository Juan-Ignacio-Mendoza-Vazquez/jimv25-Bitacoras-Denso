

<?php $__env->startSection('content'); ?>
    <h1 class="display-1">Registrar Visitas</h1>
    <br>
    <div class="container text-start">
        <form class="row g-3" id="registar-visita">
            <div class="col-md-6">
                <label class="form-label" for="name" required>Nombre:</label>
                <input placeholder="Ingrese su nombre completo" type="text" class="form-control" name="name" id="name">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="company">Empresa:</label>
                <input placeholder="Ingrese de que empresa viene" type="text" class="form-control" name="company" id="company">
            </div>
            <div class="col-12 mb-3">
                <label class="form-label" for="motivo">Motivo:</label>
                <textarea placeholder="Ingrese la razon de visita" class="form-control" name="reason" id="reason"></textarea>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="hour">Hora:</label>
                <input type="time" class="form-control" name="hour" id="hour">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label" for="photo">Fotografia:</label>
                <input type="file" class="form-control" name="photo" id="photo">
            </div>
            <div class="col-md-6 mb-3">
                <button type="submit" class="btn btn-outline-danger">Registrar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexs\OneDrive\Documentos\ASB\Proyectos\DENSO\bitacoras\resources\views/registrarvisita.blade.php ENDPATH**/ ?>